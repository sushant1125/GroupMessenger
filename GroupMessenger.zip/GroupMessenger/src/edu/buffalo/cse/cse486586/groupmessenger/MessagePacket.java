package edu.buffalo.cse.cse486586.groupmessenger;

public class MessagePacket {
	String msg = null;
	int portno;
	int [] vector = new int[5];
	public MessagePacket(String msg,int portno) {
		// TODO Auto-generated constructor stub
		this.msg=msg;
		this.portno = portno;
	//	this.vector=vector;
	}

}
